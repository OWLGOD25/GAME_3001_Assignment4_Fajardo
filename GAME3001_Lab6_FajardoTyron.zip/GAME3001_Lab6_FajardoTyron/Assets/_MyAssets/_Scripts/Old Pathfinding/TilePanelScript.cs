using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TilePanelScript : MonoBehaviour
{
    public TMP_Text statusText;
    public TMP_Text costText;
}
